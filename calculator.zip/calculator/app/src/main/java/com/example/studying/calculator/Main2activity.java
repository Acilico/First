package com.example.studying.calculator;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;

public class Main2activity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

    }

    public void OnClick2(View v){
        EditText c1 = findViewById(R.id.editText2);
        EditText d1 = findViewById(R.id.editText3);
        String s2;
        String p2;
        s2 = c1.getText().toString();
        p2 = d1.getText().toString();
        Intent intent = new Intent(this,MainActivity.class);
        intent.putExtra("Login", s2);
        intent.putExtra("Password", p2);
        startActivity(intent);
    }
}
