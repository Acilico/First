package com.example.studying.calculator;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
public String log, pas;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        log = getIntent().getStringExtra("Login");
        pas = getIntent().getStringExtra("Password");
        EditText a1 = findViewById(R.id.editText);
        a1.setText(log);

        }


    public void OnClick(View v){
        EditText a1 = findViewById(R.id.editText);
        EditText b1 = findViewById(R.id.editText1);
        String s1;
        String s0 = "Admin";
        String p0 = "12345";
        String p1;
        s1 = a1.getText().toString();
        p1 = b1.getText().toString();
        if ((s1.equals(s0) && p1.equals(p0)) || (s1.equals(log) && p1.equals(pas))) {
            TextView t1 = findViewById(R.id.textView);
            t1.setText("CORRECT");
        }
        else {
            Intent intent = new Intent(this, Main2activity.class);
            startActivity(intent);
        }
    }
}
